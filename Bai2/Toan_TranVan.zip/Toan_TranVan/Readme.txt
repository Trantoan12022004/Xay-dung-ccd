Câu 1:
- Sửa file token.c, phần khai báo TokenType, từ dòng 15 đến 34
- Sửa file token.c, hàm keywordEq, từ dùng 39 đến 45
Câu 2:
- Sửa file token.h, thêm KW_RETURN, KW_SWITCH, (Dòng 22),   {"return", KW_RETURN},
  {"switch", KW_SWITCH}, (dòng 35, 36)
- Sửa file scanner.c dòng 348, 349
Câu 3:
- Sửa file charcode.c dòng 23
- sửa file charcode.h dòng 30, 31
- sửa file scanner.c hàm getToken dòng 297, 302 
Câu 4:
- sửa file scanner.c hàm getToken dòng 201-204
Câu 5:
-Sửa file token.h dòng 27
Câu 6:
- sửa file charcode.c 
- sửa file scanner.c dòng 71, 80
- sửa token.h #define MAX_IDENT_LEN 10
Câu 7:
sửa file scanner.c dòng 57, 64 hàm  skipLineComment, hàm getToken dòng 186 - 188
